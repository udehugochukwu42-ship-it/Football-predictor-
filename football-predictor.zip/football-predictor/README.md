# Matchday — Statistical Football Previews

Live fixtures, live scores, recent results, and statistical predictions
(match winner, over 2.5 goals, both teams to score, first-half over 0.5
goals) built on top of the [football-data.org](https://www.football-data.org)
free API.

**Important:** these predictions are statistical estimates from recent
match data, not guarantees. The app says this in the UI too — keep it
that way if you extend it.

---

## 1. Get your free API key

1. Go to **https://www.football-data.org/client/register** and sign up
   (free, no card needed).
2. After registering, your API key is shown on your account page and
   also emailed to you.
3. Free tier gives you: **12 competitions**, **10 requests/minute**,
   and fixtures/results/tables (scores are slightly delayed, not
   real-time — see Limitations below).

The 12 free competitions: Premier League, La Liga, Bundesliga, Serie A,
Ligue 1, Champions League, Championship, Eredivisie, Primeira Liga,
Brazilian Série A, World Cup, European Championship. That's the full
set this app is built around (`src/competitions.js`) — if you ever
upgrade your plan, just add more competition codes to that one file.

---

## 2. Run it locally (optional — you can skip straight to deployment)

```bash
cd football-predictor
npm install
cp .env.example .env
# edit .env and paste your API key into FOOTBALL_DATA_API_KEY
npm start
```

Visit `http://localhost:3000`.

---

## 3. Deploy from your phone: GitHub + Render

### A. Push the code to GitHub
1. In the GitHub app (or github.com in your phone browser), create a new
   **empty** repository, e.g. `football-predictor`.
2. Easiest phone-friendly path: use GitHub's "upload files" web page
   (`github.com/<you>/football-predictor/upload`) and upload every file
   in this project **except** `node_modules/`, `.env`, and `data/*.db`
   (the `.gitignore` already excludes these if you use git directly from
   a laptop/Codespaces instead).
3. If you have access to GitHub Codespaces or Termux, `git init`,
   `git add .`, `git commit -m "Initial commit"`, and push — normal git
   flow works fine too.

### B. Deploy on Render (free tier, works entirely from a phone browser)
1. Go to **https://render.com**, sign up, and connect your GitHub account.
2. **New +** → **Web Service** → pick your `football-predictor` repo.
3. Settings:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** Free
4. Under **Environment Variables**, add:
   - `FOOTBALL_DATA_API_KEY` → your key from step 1
5. Click **Create Web Service**. Render builds and deploys automatically.
   You'll get a URL like `https://football-predictor.onrender.com` —
   open that on your phone and it's your app.

**Note on Render's free tier:** the service sleeps after inactivity and
takes ~30–60 seconds to wake on the next visit. That's normal, not a bug.

### C. SQLite on Render's free tier
Render's free web services use an **ephemeral filesystem** — the
`data/football.db` cache file gets wiped on every redeploy/restart.
That's fine for this app since everything in it is a *rebuildable cache*
(nothing is lost — it just refetches from football-data.org). If you
later want the cache to survive restarts, add a Render **persistent
disk** (small paid add-on) mounted at `/opt/render/project/src/data`.

---

## 4. How the pieces fit together

```
public/           → static frontend (plain HTML/CSS/JS, no build step —
                     easiest to edit and re-upload from a phone)
server.js         → Express app: serves the frontend + mounts API routes
src/footballDataClient.js → talks to football-data.org, rate-limited to
                     stay under the free tier's 10 req/min
src/cache.js       → SQLite-backed cache: serves fresh data when
                     available, falls back to the last good copy if a
                     live call fails or gets rate-limited
src/predictor.js   → the prediction engine (see below)
src/routes/*.js    → /api/fixtures, /api/live, /api/team, /api/predict
data/football.db   → SQLite cache file (auto-created)
```

Your API key only ever lives in `.env` / Render's environment variables
on the **server**. The frontend never sees it — it only talks to your
own `/api/...` routes.

---

## 5. The prediction engine, in plain terms

For a given fixture, the app pulls each team's last ~50 finished matches
and computes, split by home/away venue where there's enough data:
- average goals scored/conceded
- how often the team's matches went over 2.5 total goals
- how often both teams scored
- how often there was a first-half goal
- head-to-head record between the two teams (last 10 meetings)

It then blends two things:
1. A **Poisson goal model** — turns each team's scoring/conceding rate
   into an expected-goals number for this fixture, then works out the
   probability of every realistic scoreline to get Home/Draw/Away and
   over/under probabilities.
2. **Raw historical frequency** — e.g. "both teams scored in 7 of this
   team's last 10 matches."

Blending both (60% model / 40% raw frequency) keeps a single hot or cold
streak from dominating, while still grounding predictions in an actual
statistical model. Every prediction ships with the underlying counts
(e.g. "8/10 home games") so you can judge the reasoning yourself —
that's shown directly in the UI under each prediction.

Confidence percentages are capped between 10–90% on purpose: the model
is never allowed to claim near-certainty.

---

## 6. Limitations to know about (free tier)

- **Only 12 competitions.** No NPFL, no MLS, no Turkish Süper Lig, etc.,
  unless you upgrade your football-data.org plan.
- **Scores are delayed**, not truly real-time, on the free tier. The
  Live tab shows a note about this.
- **10 requests/minute.** The app's rate limiter and caching handle this
  automatically, but if you add features that call the API a lot more,
  watch for `429` errors in the logs.
- New teams/fixtures with little match history will show "not enough
  data yet" instead of a forced prediction — that's intentional, not a
  bug.

---

## 7. Ideas for later (not built yet)

- A scheduled background refresh (cron) instead of fetch-on-request, so
  the homepage loads instantly even on a cold cache.
- Team crest images (football-data.org returns crest URLs already —
  just wire them into `app.js`).
- A "my predictions vs results" tracker to see how the model performs
  over time, stored in SQLite.
