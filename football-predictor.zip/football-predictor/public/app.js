const state = {
  tab: 'today',
  competition: '',
  predictionCache: new Map(), // matchId -> prediction payload (session only)
};

const contentEl = document.getElementById('content');
const filterEl = document.getElementById('competition-filter');

const COMPETITION_NAMES = {}; // filled in from /api/competitions

async function init() {
  await loadCompetitions();
  wireTabs();
  wireFilter();
  await loadTab('today');
}

async function loadCompetitions() {
  try {
    const res = await fetch('/api/competitions');
    const data = await res.json();
    data.competitions.forEach((c) => {
      COMPETITION_NAMES[c.code] = c.name;
      const opt = document.createElement('option');
      opt.value = c.code;
      opt.textContent = c.name;
      filterEl.appendChild(opt);
    });
  } catch {
    // Non-fatal — filter just stays as "All leagues".
  }
}

function wireTabs() {
  document.querySelectorAll('.tab').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach((b) => b.setAttribute('aria-selected', 'false'));
      btn.setAttribute('aria-selected', 'true');
      state.tab = btn.dataset.tab;
      loadTab(state.tab);
    });
  });
}

function wireFilter() {
  filterEl.addEventListener('change', () => {
    state.competition = filterEl.value;
    loadTab(state.tab);
  });
}

async function loadTab(tab) {
  contentEl.innerHTML = '<div class="loading">Loading…</div>';
  try {
    let url;
    if (tab === 'today') url = '/api/fixtures/today';
    else if (tab === 'live') url = '/api/live';
    else if (tab === 'upcoming') url = `/api/fixtures/upcoming?days=7${state.competition ? `&competition=${state.competition}` : ''}`;
    else url = `/api/fixtures/results${state.competition ? `?competition=${state.competition}` : ''}`;

    const res = await fetch(url);
    const data = await res.json();
    const matches = tab === 'live' ? data.matches : data.fixtures;
    const filtered = state.competition && tab !== 'live'
      ? matches.filter((m) => m.competitionCode === state.competition)
      : matches;

    renderFixtures(filtered, tab, data);
  } catch (err) {
    contentEl.innerHTML = `<div class="error-state">Couldn't load data right now. Pull to refresh or try again shortly.</div>`;
  }
}

function renderFixtures(matches, tab, meta) {
  if (!matches || matches.length === 0) {
    const msg = {
      today: 'No fixtures scheduled today across the covered leagues.',
      live: 'No matches in play right now.',
      upcoming: 'No upcoming fixtures found for this selection.',
      results: 'No recent results found for this selection.',
    }[tab];
    contentEl.innerHTML = `<div class="empty-state">${msg}</div>`;
    return;
  }

  const grouped = {};
  matches.forEach((m) => {
    const code = m.competitionCode;
    if (!grouped[code]) grouped[code] = [];
    grouped[code].push(m);
  });

  contentEl.innerHTML = '';

  if (meta && meta.errors && meta.errors.length) {
    const note = document.createElement('div');
    note.className = 'empty-state';
    note.style.padding = '8px 4px';
    note.style.fontSize = '11px';
    note.textContent = `Some leagues couldn't be refreshed right now — showing what's available.`;
    contentEl.appendChild(note);
  }

  Object.entries(grouped).forEach(([code, list]) => {
    const title = document.createElement('div');
    title.className = 'comp-group__title';
    title.textContent = COMPETITION_NAMES[code] || code;
    contentEl.appendChild(title);

    list
      .sort((a, b) => new Date(a.utcDate) - new Date(b.utcDate))
      .forEach((match) => contentEl.appendChild(buildFixtureCard(match)));
  });
}

function buildFixtureCard(match) {
  const card = document.createElement('div');
  card.className = 'fixture-card';

  const row = document.createElement('button');
  row.className = 'fixture-card__row';

  const teams = document.createElement('div');
  teams.className = 'fixture-teams';
  teams.innerHTML = `
    <span class="fixture-team fixture-team--home">${match.homeTeam.name}</span>
    <span class="fixture-team">${match.awayTeam.name}</span>
  `;

  const meta = document.createElement('div');
  meta.className = 'fixture-meta';

  const isLive = match.status === 'IN_PLAY' || match.status === 'PAUSED';
  const isFinished = match.status === 'FINISHED';
  const hasScore = match.score && match.score.fullTime && match.score.fullTime.home !== null;

  if (isLive) {
    meta.innerHTML = `<span class="fixture-live-badge">LIVE</span><span class="fixture-score">${match.score.fullTime.home ?? 0}–${match.score.fullTime.away ?? 0}</span>`;
  } else if (isFinished && hasScore) {
    meta.innerHTML = `<span class="fixture-score">${match.score.fullTime.home}–${match.score.fullTime.away}</span><span class="fixture-time">FT</span>`;
  } else {
    const kickoff = new Date(match.utcDate);
    const timeStr = kickoff.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const dateStr = kickoff.toLocaleDateString([], { month: 'short', day: 'numeric' });
    meta.innerHTML = `<span class="fixture-time">${dateStr}</span><span class="fixture-time">${timeStr}</span>`;
  }

  row.appendChild(teams);
  row.appendChild(meta);
  card.appendChild(row);

  const panel = document.createElement('div');
  panel.className = 'prediction-panel';
  card.appendChild(panel);

  row.addEventListener('click', () => togglePrediction(match, panel));

  return card;
}

async function togglePrediction(match, panel) {
  const isOpen = panel.classList.contains('open');
  if (isOpen) {
    panel.classList.remove('open');
    return;
  }
  panel.classList.add('open');

  if (state.predictionCache.has(match.id)) {
    renderPrediction(panel, state.predictionCache.get(match.id));
    return;
  }

  panel.innerHTML = '<div class="prediction-panel__loading">Crunching recent form…</div>';
  try {
    const res = await fetch(`/api/predict/${match.id}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Prediction unavailable');
    state.predictionCache.set(match.id, data);
    renderPrediction(panel, data);
  } catch (err) {
    panel.innerHTML = `<div class="prediction-panel__error">No prediction available yet for this match — try again closer to kickoff.</div>`;
  }
}

function renderPrediction(panel, data) {
  if (data.insufficientData) {
    panel.innerHTML = `<div class="insufficient-data">${data.message}</div>`;
    return;
  }

  const { matchWinner, over25, bothTeamsToScore, firstHalfOver05, sampleSizes } = data;

  panel.innerHTML = `
    <div class="pred-block">
      <div class="pred-block__label">Match Winner</div>
      <div class="pred-block__pick">${winnerLabel(matchWinner.pick, data)} <span class="confidence-num">${matchWinner.confidence}%</span></div>
      <div class="conf-bar">
        <div class="conf-bar__seg conf-bar__seg--home" style="width:${matchWinner.probabilities.home}%"></div>
        <div class="conf-bar__seg conf-bar__seg--draw" style="width:${matchWinner.probabilities.draw}%"></div>
        <div class="conf-bar__seg conf-bar__seg--away" style="width:${matchWinner.probabilities.away}%"></div>
      </div>
      <div class="conf-legend"><span>H ${matchWinner.probabilities.home}%</span><span>D ${matchWinner.probabilities.draw}%</span><span>A ${matchWinner.probabilities.away}%</span></div>
      <div class="pred-block__reasoning">${matchWinner.reasoning}</div>
    </div>

    ${yesNoBlock('Over 2.5 Goals', over25)}
    ${yesNoBlock('Both Teams To Score', bothTeamsToScore)}
    ${yesNoBlock('First Half Over 0.5 Goals', firstHalfOver05)}

    <div class="pred-block__reasoning" style="margin-top:4px;opacity:.8;">
      Based on ${sampleSizes.home} home-team and ${sampleSizes.away} away-team recent matches${sampleSizes.h2h ? `, plus ${sampleSizes.h2h} head-to-head meetings` : ''}.
    </div>
  `;
}

function yesNoBlock(label, block) {
  const yesWidth = block.prediction === 'YES' ? block.confidence : 100 - block.confidence;
  return `
    <div class="pred-block">
      <div class="pred-block__label">${label}</div>
      <div class="pred-block__pick">${block.prediction} <span class="confidence-num">${block.confidence}%</span></div>
      <div class="conf-bar">
        <div class="conf-bar__seg conf-bar__seg--yes" style="width:${yesWidth}%"></div>
        <div class="conf-bar__seg conf-bar__seg--no" style="width:${100 - yesWidth}%"></div>
      </div>
      <div class="pred-block__reasoning">${block.reasoning}</div>
    </div>
  `;
}

function winnerLabel(pick, data) {
  if (pick === 'HOME') return `${data.homeTeam.name} to win`;
  if (pick === 'AWAY') return `${data.awayTeam.name} to win`;
  return 'Draw';
}

init();
