require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const competitionsRouter = require('./src/routes/competitions');
const fixturesRouter = require('./src/routes/fixtures');
const liveRouter = require('./src/routes/live');
const teamsRouter = require('./src/routes/teams');
const predictionsRouter = require('./src/routes/predictions');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/competitions', competitionsRouter);
app.use('/api/fixtures', fixturesRouter);
app.use('/api/live', liveRouter);
app.use('/api/team', teamsRouter);
app.use('/api/predict', predictionsRouter);

app.use(express.static(path.join(__dirname, 'public')));

// Client-side routing fallback (keeps this a single static-file app).
app.get(/^(?!\/api\/).*/, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Football predictor running on port ${PORT}`);
  if (!process.env.FOOTBALL_DATA_API_KEY) {
    console.warn(
      'WARNING: FOOTBALL_DATA_API_KEY is not set. Add it to .env (see .env.example).'
    );
  }
});
