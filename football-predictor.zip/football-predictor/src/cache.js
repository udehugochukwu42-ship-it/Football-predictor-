const db = require('./db');

/**
 * getOrFetch(key, ttlSeconds, fetchFn)
 *
 * - Fresh cache hit  -> return cached data immediately, no API call.
 * - Cache expired    -> try fetchFn(). On success, store + return fresh data.
 *                       On failure (rate limit, network error, API down),
 *                       fall back to the stale cached copy and flag it.
 * - No cache at all  -> try fetchFn(). On failure, throw (caller turns this
 *                       into a "no data yet" response instead of a crash).
 */
async function getOrFetch(key, ttlSeconds, fetchFn) {
  const now = Date.now();
  const row = db
    .prepare('SELECT payload, expires_at FROM api_cache WHERE cache_key = ?')
    .get(key);

  if (row && row.expires_at > now) {
    return { data: JSON.parse(row.payload), stale: false, fromCache: true };
  }

  try {
    const fresh = await fetchFn();
    const expiresAt = now + ttlSeconds * 1000;
    db.prepare(
      `INSERT INTO api_cache (cache_key, payload, updated_at, expires_at)
       VALUES (?, ?, ?, ?)
       ON CONFLICT(cache_key) DO UPDATE SET
         payload = excluded.payload,
         updated_at = excluded.updated_at,
         expires_at = excluded.expires_at`
    ).run(key, JSON.stringify(fresh), now, expiresAt);
    return { data: fresh, stale: false, fromCache: false };
  } catch (err) {
    if (row) {
      return {
        data: JSON.parse(row.payload),
        stale: true,
        fromCache: true,
        error: err.message,
      };
    }
    throw err;
  }
}

module.exports = { getOrFetch };
