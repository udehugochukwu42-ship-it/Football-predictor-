// These are the only competitions football-data.org's free tier grants
// access to. If you upgrade your plan later, add more codes here —
// nothing else in the app needs to change.
const COMPETITIONS = [
  { code: 'PL', name: 'Premier League', country: 'England' },
  { code: 'PD', name: 'La Liga', country: 'Spain' },
  { code: 'BL1', name: 'Bundesliga', country: 'Germany' },
  { code: 'SA', name: 'Serie A', country: 'Italy' },
  { code: 'FL1', name: 'Ligue 1', country: 'France' },
  { code: 'CL', name: 'Champions League', country: 'Europe' },
  { code: 'ELC', name: 'Championship', country: 'England' },
  { code: 'DED', name: 'Eredivisie', country: 'Netherlands' },
  { code: 'PPL', name: 'Primeira Liga', country: 'Portugal' },
  { code: 'BSA', name: 'Série A', country: 'Brazil' },
  { code: 'WC', name: 'World Cup', country: 'International' },
  { code: 'EC', name: 'European Championship', country: 'International' },
];

module.exports = COMPETITIONS;
