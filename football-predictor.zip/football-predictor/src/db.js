const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(path.join(dataDir, 'football.db'));
db.pragma('journal_mode = WAL');

// Generic cache for every football-data.org response we make.
// This is what lets the app survive rate limits and outages: if a fresh
// call fails, we fall back to the last good payload instead of crashing.
db.exec(`
  CREATE TABLE IF NOT EXISTS api_cache (
    cache_key   TEXT PRIMARY KEY,
    payload     TEXT NOT NULL,
    updated_at  INTEGER NOT NULL,
    expires_at  INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS predictions_cache (
    match_id      INTEGER PRIMARY KEY,
    generated_at  INTEGER NOT NULL,
    payload       TEXT NOT NULL
  );
`);

module.exports = db;
