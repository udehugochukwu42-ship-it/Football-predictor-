const BASE_URL = 'https://api.football-data.org/v4';

// football-data.org free tier allows 10 requests/minute. We stay under
// that with a small rolling-window limiter so we never get hard-blocked.
const MAX_REQUESTS_PER_MINUTE = 9;
const requestTimestamps = [];

async function waitForSlot() {
  const now = Date.now();
  while (requestTimestamps.length && now - requestTimestamps[0] > 60_000) {
    requestTimestamps.shift();
  }
  if (requestTimestamps.length >= MAX_REQUESTS_PER_MINUTE) {
    const waitMs = 60_000 - (now - requestTimestamps[0]) + 250;
    await new Promise((resolve) => setTimeout(resolve, waitMs));
    return waitForSlot();
  }
  requestTimestamps.push(Date.now());
}

async function fdFetch(pathname, params = {}) {
  const apiKey = process.env.FOOTBALL_DATA_API_KEY;
  if (!apiKey) {
    const err = new Error(
      'FOOTBALL_DATA_API_KEY is not set. Add it to your .env file.'
    );
    err.code = 'NO_API_KEY';
    throw err;
  }

  await waitForSlot();

  const url = new URL(BASE_URL + pathname);
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null) {
      url.searchParams.set(key, value);
    }
  });

  const res = await fetch(url, { headers: { 'X-Auth-Token': apiKey } });

  if (res.status === 429) {
    const err = new Error('Rate limited by football-data.org');
    err.code = 'RATE_LIMITED';
    throw err;
  }
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    const err = new Error(`football-data.org error ${res.status}: ${body}`);
    err.code = 'API_ERROR';
    err.status = res.status;
    throw err;
  }

  return res.json();
}

module.exports = { fdFetch };
