// Prediction engine
// -------------------
// Combines two approaches:
//  1. A Poisson goal model built from each team's recent scoring/conceding
//     rates (venue-specific where we have enough data).
//  2. Raw historical frequencies (e.g. "over 2.5 goals in 7/10 matches").
// The two are blended so a single unlucky small sample can't dominate,
// and every prediction ships with the underlying counts so the person
// using it can judge the reasoning themselves. None of this is a
// guarantee — it's a statistical estimate from limited recent data.

function logFactorial(n) {
  let sum = 0;
  for (let i = 2; i <= n; i++) sum += Math.log(i);
  return sum;
}

function poissonPmf(k, lambda) {
  if (lambda <= 0) return k === 0 ? 1 : 0;
  const logP = -lambda + k * Math.log(lambda) - logFactorial(k);
  return Math.exp(logP);
}

// Keep confidence numbers from ever claiming false certainty.
function clampPct(p) {
  return Math.min(90, Math.max(10, Math.round(p * 100)));
}

function hasScore(m) {
  return (
    m &&
    m.score &&
    m.score.fullTime &&
    m.score.fullTime.home !== null &&
    m.score.fullTime.home !== undefined &&
    m.score.fullTime.away !== null &&
    m.score.fullTime.away !== undefined
  );
}

/**
 * venue: 'home' | 'away' | null (null = all matches regardless of venue)
 */
function analyzeTeamMatches(matches, teamId, venue) {
  const filtered = (matches || [])
    .filter((m) => {
      if (venue === 'home') return m.homeTeam.id === teamId;
      if (venue === 'away') return m.awayTeam.id === teamId;
      return true;
    })
    .filter(hasScore);

  const n = filtered.length;
  if (n === 0) return { sampleSize: 0 };

  let scored = 0,
    conceded = 0,
    btts = 0,
    over25 = 0,
    firstHalfOver05 = 0,
    wins = 0,
    draws = 0,
    losses = 0;

  filtered.forEach((m) => {
    const isHome = m.homeTeam.id === teamId;
    const gf = isHome ? m.score.fullTime.home : m.score.fullTime.away;
    const ga = isHome ? m.score.fullTime.away : m.score.fullTime.home;
    scored += gf;
    conceded += ga;
    if (gf > 0 && ga > 0) btts++;
    if (gf + ga > 2) over25++;

    const ht = m.score.halfTime || {};
    if (ht.home != null && ht.away != null && ht.home + ht.away > 0) {
      firstHalfOver05++;
    }

    if (m.score.winner === 'DRAW') draws++;
    else if (
      (isHome && m.score.winner === 'HOME_TEAM') ||
      (!isHome && m.score.winner === 'AWAY_TEAM')
    )
      wins++;
    else losses++;
  });

  return {
    sampleSize: n,
    avgScored: scored / n,
    avgConceded: conceded / n,
    bttsRate: btts / n,
    over25Rate: over25 / n,
    firstHalfOver05Rate: firstHalfOver05 / n,
    bttsCount: btts,
    over25Count: over25,
    firstHalfCount: firstHalfOver05,
    wins,
    draws,
    losses,
  };
}

function analyzeH2H(h2hMatches, homeTeamId) {
  const filtered = (h2hMatches || []).filter(hasScore);
  const n = filtered.length;
  if (n === 0) return { sampleSize: 0 };

  let homeWins = 0,
    awayWins = 0,
    draws = 0,
    btts = 0,
    over25 = 0,
    firstHalfOver05 = 0,
    totalGoals = 0;

  filtered.forEach((m) => {
    const homeSideIsOurHomeTeam = m.homeTeam.id === homeTeamId;
    const h = m.score.fullTime.home;
    const a = m.score.fullTime.away;
    totalGoals += h + a;
    if (h > 0 && a > 0) btts++;
    if (h + a > 2) over25++;

    const ht = m.score.halfTime || {};
    if (ht.home != null && ht.away != null && ht.home + ht.away > 0) {
      firstHalfOver05++;
    }

    if (m.score.winner === 'DRAW') draws++;
    else if (m.score.winner === 'HOME_TEAM') {
      homeSideIsOurHomeTeam ? homeWins++ : awayWins++;
    } else if (m.score.winner === 'AWAY_TEAM') {
      homeSideIsOurHomeTeam ? awayWins++ : homeWins++;
    }
  });

  return {
    sampleSize: n,
    homeWins,
    awayWins,
    draws,
    bttsRate: btts / n,
    over25Rate: over25 / n,
    firstHalfOver05Rate: firstHalfOver05 / n,
    avgTotalGoals: totalGoals / n,
  };
}

function computePrediction({
  homeTeamId,
  awayTeamId,
  homeTeamName,
  awayTeamName,
  homeMatches,
  awayMatches,
  h2hMatches,
}) {
  const homeHomeStats = analyzeTeamMatches(homeMatches, homeTeamId, 'home');
  const awayAwayStats = analyzeTeamMatches(awayMatches, awayTeamId, 'away');
  const homeOverallStats = analyzeTeamMatches(homeMatches, homeTeamId, null);
  const awayOverallStats = analyzeTeamMatches(awayMatches, awayTeamId, null);
  const h2h = analyzeH2H(h2hMatches, homeTeamId);

  // Prefer venue-specific form, but fall back to overall recent form if
  // there isn't enough venue-specific history yet.
  const hs = homeHomeStats.sampleSize >= 3 ? homeHomeStats : homeOverallStats;
  const as = awayAwayStats.sampleSize >= 3 ? awayAwayStats : awayOverallStats;
  const hsVenueLabel = hs === homeHomeStats ? 'home' : 'overall recent';
  const asVenueLabel = as === awayAwayStats ? 'away' : 'overall recent';

  if (hs.sampleSize === 0 || as.sampleSize === 0) {
    return {
      insufficientData: true,
      message:
        'Not enough completed-match history for one or both teams yet — check back closer to kickoff.',
    };
  }

  // Expected goals: blend each team's attack with the opponent's defence,
  // with a small home-advantage adjustment.
  const homeExpGoals = ((hs.avgScored + as.avgConceded) / 2) * 1.1;
  const awayExpGoals = ((as.avgScored + hs.avgConceded) / 2) * 0.95;

  const MAX_GOALS = 6;
  let pHomeWin = 0,
    pDraw = 0,
    pAwayWin = 0,
    pOver25 = 0,
    pBtts = 0;

  for (let i = 0; i <= MAX_GOALS; i++) {
    for (let j = 0; j <= MAX_GOALS; j++) {
      const p = poissonPmf(i, homeExpGoals) * poissonPmf(j, awayExpGoals);
      if (i > j) pHomeWin += p;
      else if (i === j) pDraw += p;
      else pAwayWin += p;
      if (i + j > 2) pOver25 += p;
      if (i > 0 && j > 0) pBtts += p;
    }
  }

  const h2hOver25 = h2h.sampleSize > 0 ? h2h.over25Rate : (hs.over25Rate + as.over25Rate) / 2;
  const h2hBtts = h2h.sampleSize > 0 ? h2h.bttsRate : (hs.bttsRate + as.bttsRate) / 2;
  const h2hFirstHalf =
    h2h.sampleSize > 0
      ? h2h.firstHalfOver05Rate
      : (hs.firstHalfOver05Rate + as.firstHalfOver05Rate) / 2;

  // 60% model, 40% raw historical frequency — keeps a hot/cold streak
  // from being the only signal, but still lets the model dominate.
  const blendedOver25 = pOver25 * 0.6 + ((hs.over25Rate + as.over25Rate + h2hOver25) / 3) * 0.4;
  const blendedBtts = pBtts * 0.6 + ((hs.bttsRate + as.bttsRate + h2hBtts) / 3) * 0.4;
  const firstHalfRate = (hs.firstHalfOver05Rate + as.firstHalfOver05Rate + h2hFirstHalf) / 3;

  let winnerPick = 'DRAW',
    winnerConf = pDraw;
  if (pHomeWin > pDraw && pHomeWin > pAwayWin) {
    winnerPick = 'HOME';
    winnerConf = pHomeWin;
  } else if (pAwayWin > pDraw && pAwayWin > pHomeWin) {
    winnerPick = 'AWAY';
    winnerConf = pAwayWin;
  }

  const h2hSentence =
    h2h.sampleSize > 0
      ? `Head-to-head (last ${h2h.sampleSize}): ${homeTeamName} ${h2h.homeWins}W, ${h2h.draws}D, ${awayTeamName} ${h2h.awayWins}W.`
      : 'No recent head-to-head meetings in our data yet.';

  return {
    insufficientData: false,
    sampleSizes: { home: hs.sampleSize, away: as.sampleSize, h2h: h2h.sampleSize },
    expectedGoals: {
      home: Number(homeExpGoals.toFixed(2)),
      away: Number(awayExpGoals.toFixed(2)),
    },
    matchWinner: {
      pick: winnerPick,
      confidence: clampPct(winnerConf),
      probabilities: {
        home: clampPct(pHomeWin),
        draw: clampPct(pDraw),
        away: clampPct(pAwayWin),
      },
      reasoning: `${homeTeamName} average ${hs.avgScored.toFixed(2)} scored / ${hs.avgConceded.toFixed(
        2
      )} conceded per game in ${hsVenueLabel} matches (${hs.sampleSize} games). ${awayTeamName} average ${as.avgScored.toFixed(
        2
      )} scored / ${as.avgConceded.toFixed(2)} conceded in ${asVenueLabel} matches (${as.sampleSize} games). ${h2hSentence}`,
    },
    over25: {
      prediction: blendedOver25 >= 0.5 ? 'YES' : 'NO',
      confidence: clampPct(Math.max(blendedOver25, 1 - blendedOver25)),
      rate: Math.round(blendedOver25 * 100),
      reasoning: `${homeTeamName} went over 2.5 goals in ${hs.over25Count}/${hs.sampleSize} recent ${hsVenueLabel} matches; ${awayTeamName} in ${as.over25Count}/${as.sampleSize} ${asVenueLabel} matches.`,
    },
    bothTeamsToScore: {
      prediction: blendedBtts >= 0.5 ? 'YES' : 'NO',
      confidence: clampPct(Math.max(blendedBtts, 1 - blendedBtts)),
      rate: Math.round(blendedBtts * 100),
      reasoning: `Both teams scored in ${hs.bttsCount}/${hs.sampleSize} of ${homeTeamName}'s recent ${hsVenueLabel} matches and ${as.bttsCount}/${as.sampleSize} of ${awayTeamName}'s ${asVenueLabel} matches.`,
    },
    firstHalfOver05: {
      prediction: firstHalfRate >= 0.5 ? 'YES' : 'NO',
      confidence: clampPct(Math.max(firstHalfRate, 1 - firstHalfRate)),
      rate: Math.round(firstHalfRate * 100),
      reasoning: `${homeTeamName} had a first-half goal in ${hs.firstHalfCount}/${hs.sampleSize} recent ${hsVenueLabel} matches; ${awayTeamName} in ${as.firstHalfCount}/${as.sampleSize} ${asVenueLabel} matches.`,
    },
    generatedAt: new Date().toISOString(),
  };
}

module.exports = { computePrediction };
