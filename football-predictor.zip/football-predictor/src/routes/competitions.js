const express = require('express');
const router = express.Router();
const COMPETITIONS = require('../competitions');

router.get('/', (req, res) => {
  res.json({ competitions: COMPETITIONS });
});

module.exports = router;
