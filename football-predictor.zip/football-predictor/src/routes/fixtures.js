const express = require('express');
const router = express.Router();
const { fdFetch } = require('../footballDataClient');
const { getOrFetch } = require('../cache');
const COMPETITIONS = require('../competitions');

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}
function addDaysStr(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

// Fetch a date range for a single competition, cached, with per-competition
// error isolation so one broken/rate-limited league can't take down the rest.
async function fetchCompetitionRange(code, dateFrom, dateTo, ttlSeconds) {
  const key = `matches:${code}:${dateFrom}:${dateTo}`;
  try {
    const result = await getOrFetch(key, ttlSeconds, () =>
      fdFetch(`/competitions/${code}/matches`, { dateFrom, dateTo })
    );
    return {
      code,
      matches: result.data.matches || [],
      stale: result.stale,
      error: result.error || null,
    };
  } catch (err) {
    return { code, matches: [], stale: false, error: err.message };
  }
}

router.get('/today', async (req, res) => {
  const today = todayStr();
  const results = [];
  for (const comp of COMPETITIONS) {
    // Sequential on purpose: the client's own rate limiter will throttle
    // these, and running them one at a time keeps that limiter accurate.
    results.push(await fetchCompetitionRange(comp.code, today, today, 300));
  }

  const fixtures = results.flatMap((r) =>
    r.matches.map((m) => ({ ...m, competitionCode: r.code }))
  );
  const errors = results.filter((r) => r.error).map((r) => ({ competition: r.code, message: r.error }));

  res.json({ date: today, fixtures, errors, hasData: fixtures.length > 0 });
});

router.get('/upcoming', async (req, res) => {
  const competition = req.query.competition;
  const days = Math.min(Number(req.query.days) || 7, 14);
  const dateFrom = todayStr();
  const dateTo = addDaysStr(days);

  const targetComps = competition
    ? COMPETITIONS.filter((c) => c.code === competition)
    : COMPETITIONS;

  if (competition && targetComps.length === 0) {
    return res.status(400).json({ error: `Unknown competition code "${competition}".` });
  }

  const results = [];
  for (const comp of targetComps) {
    results.push(await fetchCompetitionRange(comp.code, dateFrom, dateTo, 1800));
  }

  const fixtures = results
    .flatMap((r) => r.matches.map((m) => ({ ...m, competitionCode: r.code })))
    .filter((m) => m.status === 'SCHEDULED' || m.status === 'TIMED');
  const errors = results.filter((r) => r.error).map((r) => ({ competition: r.code, message: r.error }));

  res.json({ dateFrom, dateTo, fixtures, errors, hasData: fixtures.length > 0 });
});

router.get('/results', async (req, res) => {
  const competition = req.query.competition;
  const dateFrom = addDaysStr(-14);
  const dateTo = todayStr();

  const targetComps = competition
    ? COMPETITIONS.filter((c) => c.code === competition)
    : COMPETITIONS;

  if (competition && targetComps.length === 0) {
    return res.status(400).json({ error: `Unknown competition code "${competition}".` });
  }

  const results = [];
  for (const comp of targetComps) {
    results.push(await fetchCompetitionRange(comp.code, dateFrom, dateTo, 900));
  }

  const fixtures = results
    .flatMap((r) => r.matches.map((m) => ({ ...m, competitionCode: r.code })))
    .filter((m) => m.status === 'FINISHED')
    .sort((a, b) => new Date(b.utcDate) - new Date(a.utcDate));
  const errors = results.filter((r) => r.error).map((r) => ({ competition: r.code, message: r.error }));

  res.json({ dateFrom, dateTo, fixtures, errors, hasData: fixtures.length > 0 });
});

module.exports = router;
