const express = require('express');
const router = express.Router();
const { fdFetch } = require('../footballDataClient');
const { getOrFetch } = require('../cache');
const COMPETITIONS = require('../competitions');

router.get('/', async (req, res) => {
  const results = [];
  for (const comp of COMPETITIONS) {
    const key = `live:${comp.code}`;
    try {
      const result = await getOrFetch(key, 60, () =>
        fdFetch(`/competitions/${comp.code}/matches`, {
          status: 'IN_PLAY,PAUSED',
        })
      );
      results.push({
        code: comp.code,
        matches: (result.data.matches || []).map((m) => ({
          ...m,
          competitionCode: comp.code,
        })),
        stale: result.stale,
        error: result.error || null,
      });
    } catch (err) {
      results.push({ code: comp.code, matches: [], stale: false, error: err.message });
    }
  }

  const liveMatches = results.flatMap((r) => r.matches);
  const errors = results.filter((r) => r.error).map((r) => ({ competition: r.code, message: r.error }));

  res.json({
    matches: liveMatches,
    errors,
    hasData: liveMatches.length > 0,
    note: 'Free-tier data can lag a few minutes behind the real match clock.',
  });
});

module.exports = router;
