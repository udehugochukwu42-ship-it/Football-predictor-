const express = require('express');
const router = express.Router();
const { fdFetch } = require('../footballDataClient');
const { getOrFetch } = require('../cache');
const { computePrediction } = require('../predictor');
const db = require('../db');

const PREDICTION_CACHE_TTL_MS = 6 * 60 * 60 * 1000; // 6 hours

router.get('/:matchId', async (req, res) => {
  const matchId = Number(req.params.matchId);
  if (!Number.isInteger(matchId)) {
    return res.status(400).json({ error: 'Invalid match id.' });
  }

  // Serve a fresh-enough cached prediction if we have one.
  const cached = db
    .prepare('SELECT generated_at, payload FROM predictions_cache WHERE match_id = ?')
    .get(matchId);
  if (cached && Date.now() - cached.generated_at < PREDICTION_CACHE_TTL_MS) {
    return res.json({ ...JSON.parse(cached.payload), fromCache: true });
  }

  // 1. Match details (who's playing)
  let match;
  try {
    const result = await getOrFetch(`match:${matchId}`, 300, () =>
      fdFetch(`/matches/${matchId}`)
    );
    match = result.data.match || result.data;
  } catch (err) {
    if (cached) {
      // Serve the stale prediction rather than a hard failure.
      return res.json({ ...JSON.parse(cached.payload), fromCache: true, stale: true });
    }
    return res.status(502).json({
      error: 'Could not load match details yet. Try again shortly.',
      detail: err.message,
    });
  }

  const homeTeamId = match.homeTeam.id;
  const awayTeamId = match.awayTeam.id;
  const homeTeamName = match.homeTeam.name;
  const awayTeamName = match.awayTeam.name;

  // 2. Recent match history for both teams (cached 1h per team).
  async function teamHistory(teamId) {
    try {
      const result = await getOrFetch(`team:${teamId}:finished`, 3600, () =>
        fdFetch(`/teams/${teamId}/matches`, { status: 'FINISHED', limit: 50 })
      );
      return result.data.matches || [];
    } catch {
      return [];
    }
  }
  const [homeMatches, awayMatches] = await Promise.all([
    teamHistory(homeTeamId),
    teamHistory(awayTeamId),
  ]);

  // 3. Head-to-head (cached 24h). Falls back to deriving H2H from the two
  // teams' own recent match lists if the dedicated endpoint fails.
  let h2hMatches = [];
  try {
    const result = await getOrFetch(`h2h:${matchId}`, 86400, () =>
      fdFetch(`/matches/${matchId}/head2head`, { limit: 10 })
    );
    h2hMatches = result.data.matches || [];
  } catch {
    h2hMatches = homeMatches.filter(
      (m) =>
        (m.homeTeam.id === homeTeamId && m.awayTeam.id === awayTeamId) ||
        (m.homeTeam.id === awayTeamId && m.awayTeam.id === homeTeamId)
    );
  }

  const prediction = computePrediction({
    homeTeamId,
    awayTeamId,
    homeTeamName,
    awayTeamName,
    homeMatches,
    awayMatches,
    h2hMatches,
  });

  const payload = {
    matchId,
    homeTeam: { id: homeTeamId, name: homeTeamName },
    awayTeam: { id: awayTeamId, name: awayTeamName },
    utcDate: match.utcDate,
    status: match.status,
    ...prediction,
    disclaimer:
      'Statistical estimate based on recent results only. Not a guarantee of any outcome.',
  };

  db.prepare(
    `INSERT INTO predictions_cache (match_id, generated_at, payload)
     VALUES (?, ?, ?)
     ON CONFLICT(match_id) DO UPDATE SET generated_at = excluded.generated_at, payload = excluded.payload`
  ).run(matchId, Date.now(), JSON.stringify(payload));

  res.json({ ...payload, fromCache: false });
});

module.exports = router;
