const express = require('express');
const router = express.Router();
const { fdFetch } = require('../footballDataClient');
const { getOrFetch } = require('../cache');

// Pulls a team's recent finished matches. Used both for the "last 5
// results" UI and as raw input to the prediction engine (which wants a
// bigger sample, so it requests more and slices as needed).
router.get('/:id/recent', async (req, res) => {
  const teamId = Number(req.params.id);
  const limit = Math.min(Number(req.query.limit) || 5, 50);
  const key = `team:${teamId}:finished`;

  try {
    const result = await getOrFetch(key, 3600, () =>
      fdFetch(`/teams/${teamId}/matches`, { status: 'FINISHED', limit: 50 })
    );
    const matches = (result.data.matches || [])
      .sort((a, b) => new Date(b.utcDate) - new Date(a.utcDate))
      .slice(0, limit);

    res.json({ teamId, matches, stale: result.stale, hasData: matches.length > 0 });
  } catch (err) {
    res.status(err.code === 'RATE_LIMITED' ? 429 : 502).json({
      teamId,
      matches: [],
      hasData: false,
      error: err.message,
    });
  }
});

module.exports = router;
